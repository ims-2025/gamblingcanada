import type { Pillar } from './_types';
import { onlineCasinosOntario } from './online-casinos-ontario';
import { onlineCasinosAlberta } from './online-casinos-alberta';
import { casinoBonuses } from './casino-bonuses';
import { noDepositBonusCanada } from './no-deposit-bonus-canada';
import { interacCasinos } from './interac-casinos';
import { fastestPayoutCasinos } from './fastest-payout-casinos';
import { bestBingoSites } from './best-bingo-sites';
import { isOnlineGamblingLegalInCanada } from './is-online-gambling-legal-in-canada';

export const PILLARS: Pillar[] = [
  onlineCasinosOntario,
  onlineCasinosAlberta,
  casinoBonuses,
  noDepositBonusCanada,
  interacCasinos,
  fastestPayoutCasinos,
  bestBingoSites,
  isOnlineGamblingLegalInCanada,
];

export function getPillar(slug: string): Pillar | undefined {
  return PILLARS.find((p) => p.slug === slug);
}

export type { Pillar } from './_types';
